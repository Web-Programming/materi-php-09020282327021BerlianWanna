<h1>Welcome to Login Page</h1>
<h2>Hallo 
    {{$name}}
</h2>
<h2>Ur Email 
    {{$email}}
</h2>
<h2>Ur Adress 
    {{$alamat}}
</h2>

