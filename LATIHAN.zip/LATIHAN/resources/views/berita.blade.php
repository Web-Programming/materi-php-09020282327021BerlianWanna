<div>
<p>ID Berita: {{ $id }}</p>
<p>judul: {{ $judul }}</p>
</div>
