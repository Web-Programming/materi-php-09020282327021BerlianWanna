<div>
    <!-- Simplicity is the essence of happiness. - Cedric Bledsoe -->
</div>
