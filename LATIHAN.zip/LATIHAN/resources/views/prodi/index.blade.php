@extends('layout.master')
@section('tittle', "halaman list prodi")
    

@section('content')
<div>
    <h1>Ini Halaman Prodi</h1>
</div>
@endsection
