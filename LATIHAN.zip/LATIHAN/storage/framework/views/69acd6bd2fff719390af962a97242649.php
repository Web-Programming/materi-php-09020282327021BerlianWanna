<div>
    ini header
</div>
<?php /**PATH C:\Catatan_MDP_Sem4\PW1\larevel baru\materi-php-09020282327021BerlianWanna\LATIHAN\resources\views/layout/header.blade.php ENDPATH**/ ?>