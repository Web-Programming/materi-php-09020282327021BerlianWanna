<div>
    <!-- Nothing worth having comes easy. - Theodore Roosevelt -->
</div>
<?php /**PATH C:\Catatan_MDP_Sem4\PW1\larevel baru\materi-php-09020282327021BerlianWanna\LATIHAN\resources\views/layout/footer.blade.php ENDPATH**/ ?>