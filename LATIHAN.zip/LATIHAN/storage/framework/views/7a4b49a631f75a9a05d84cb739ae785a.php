
<?php $__env->startSection('tittle', "halaman list prodi"); ?>
    

<?php $__env->startSection('content'); ?>
<div>
    <h1>Ini Halaman Prodi</h1>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Catatan_MDP_Sem4\PW1\larevel baru\materi-php-09020282327021BerlianWanna\LATIHAN\resources\views/prodi/index.blade.php ENDPATH**/ ?>