<div>
<p>ID Berita: <?php echo e($id); ?></p>
<p>judul: <?php echo e($judul); ?></p>
</div>
<?php /**PATH C:\Catatan_MDP_Sem4\PW1\larevel baru\materi-php-09020282327021BerlianWanna\LATIHAN\resources\views/berita.blade.php ENDPATH**/ ?>