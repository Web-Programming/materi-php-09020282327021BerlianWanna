<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('tittle'); ?> </title>
</head>
<body>
 <!-- ini bagian header -->
  <?php echo $__env->make('layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


 <!-- ini bagian side bar -->
    <?php echo $__env->make('layout.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

 <!-- ini bagian Content-->
 <?php echo $__env->yieldContent('content'); ?>

 <!-- ini bagian footer -->
 <?php echo $__env->make('layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html>
<?php /**PATH C:\Catatan_MDP_Sem4\PW1\larevel baru\materi-php-09020282327021BerlianWanna\LATIHAN\resources\views/layout/master.blade.php ENDPATH**/ ?>